The account contract is an optimized build of:
https://github.com/burnt-labs/contracts account contract