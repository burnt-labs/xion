package globalfee

import (
	"github.com/burnt-labs/xion/x/globalfee/types"
)

const (
	ModuleName = types.ModuleName

	StoreKey = ModuleName
)
