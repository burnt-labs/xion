package types

const (
	// ModuleName is the name of the this module
	ModuleName = "globalfee"

	QuerierRoute = ModuleName
)
